//
// Created by Perfare on 2020/7/4.
//

#ifndef RIRU_IL2CPPDUMPER_IL2CPP_H
#define RIRU_IL2CPPDUMPER_IL2CPP_H

void il2cpp_dump(void *handle);

const char* GetPackageName();

#endif //RIRU_IL2CPPDUMPER_IL2CPP_H
