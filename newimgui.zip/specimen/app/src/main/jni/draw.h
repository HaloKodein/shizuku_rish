#include "import.h"
int screenWidth, screenHeight; 
char loginData[2048];
const char* LoginCommand = "";
int Width = 0, Height = 0;
const char* LoginState = "";
//khai bao

using namespace ImGui;   
using namespace ESP; 
using namespace Il2Cpp;

const char* deviceid; 

bool showAlert, isLogin = true, showmenu;

void Alert(const char * message) {
    if (showAlert) {
        ImGui::OpenPopup("Message");
        if (ImGui::BeginPopupModal("Message", &showAlert, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove)) {
            ImGui::Text("%s", message);
            ImGui::Separator();
            if (ImGui::Button("OK", ImVec2(-1.0, 0.0f))) {
                ImGui::CloseCurrentPopup();
                showAlert = false;
            }
            ImGui::EndPopup();
        }
    }
} 

string keyReturn;
bool Login(const char * cmd) {
    char result[1024];
    FILE * pipe = popen(cmd, "r");
    LOGI("%s", cmd);
    if (!pipe) {
        LOGI("Failed to open pipe");
        return false;
    }
    while (!feof(pipe)) {
        if (fgets(result, 1024, pipe) != nullptr) {
            string toStr(result); 
            keyReturn = toStr;
            if (keyReturn.find("invalid") != string::npos) {
                isLogin = false;
                LoginState = "chưa kích hoạt";
            } else if (keyReturn.find("expired") != string::npos) { 
                isLogin = false;
                LoginState = "hết hạn";
            } else {
                isLogin = true;
            }
        }
    }
    pclose(pipe);
    return false;
}

void getLogin() {
    sprintf(loginData, "curl 'http://shyke.x10.mx/test.php?key=%s'", deviceid);
}

/*
void DrawESP() { 
    ImGuiIO &io = ImGui::GetIO();
    
    if (!(Camera_main && Camera_main()))
	{
		LOGE("Can't get Camera!");
		return;
	}
	if (!(WorldToScreenPoint))
	{
	    LOGE("Can't get WorldToScreenPoint!");
		return;
	}
    if (espZombie) {
	    DrawBox(ImVec2(screenWidth / 2, 20), ImVec2(150, 50), 40, ImVec4(0,0,0,0.8), to_string(listZombie.size()).c_str());
        for (int i = 0; i < listZombie.size(); i++)
        { 
            void *actorCharacter = *(void **)(listZombie[i] + 0x190);
    	    Vector3 Pos =  GetLocation(actorCharacter); 
    		Vector3 PosScreen = WorldToScreenPoint(Camera_main(), Pos); 
    		ImVec2 DrawTo = ImVec2(PosScreen.X , screenHeight - PosScreen.Y); 
    		if(PosScreen.Z > 0)
    		{
                DrawLine(ImVec2(screenWidth / 2, 70), DrawTo, ImVec4(1,1,1,1)); 
                const char *Distance = (to_string((int)Vector3::Distance(MyPos, Pos)) +"m").c_str();
                if (IsZombie((void*)listZombie[i])) { 
                        DrawBox(ImVec2(DrawTo.x - 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(1,0,0,0.8), "Zombie");
                        DrawBox(ImVec2(DrawTo.x + 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(1,0,0,0.8), Distance);
                } else {
                        DrawBox(ImVec2(DrawTo.x - 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(0,1,0,0.8), "Person");
                        DrawBox(ImVec2(DrawTo.x + 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(0,1,0,0.8), Distance);
                }
            }
        }
    }
    
    if(case1)
    {
        DrawBox(ImVec2(screenWidth / 2, 20), ImVec2(150, 50), 40, ImVec4(0,0,0,0.8), to_string(listObject.size()).c_str());
        for (int i = 0; i < listObject.size(); i++)
        {
            if (listObject[i] == 0) continue;
            int type = *(uint_t *)(listObject[i] + 0xC);
            if (*(float *)(listObject[i] + 0x74) > 0)
            {
    			listObject.erase(listObject.begin() + i);
    			continue;
    	    }
    		Vector3 Pos = GetLocation((void*)listObject[i]);
    		Vector3 PosScreen = WorldToScreenPoint(Camera_main(), Pos); 
    		ImVec2 DrawTo = ImVec2(PosScreen.X , screenHeight - PosScreen.Y); 
    		if(PosScreen.Z > 0)
    		{
                DrawLine(ImVec2(screenWidth / 2, 70), DrawTo, ImVec4(1,1,1,1)); 
                const char *Distance = (to_string((int)Vector3::Distance(MyPos, Pos)) +"m").c_str();
                switch (type)
                {
                    case 1:
                        DrawBox(ImVec2(DrawTo.x - 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(0,1,0,0.8), "Đá");
                    break;
                    case 2:
                        DrawBox(ImVec2(DrawTo.x - 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(0,1,0,0.8), "Que củi");
                    break; 
                }
                DrawBox(ImVec2(DrawTo.x + 75, DrawTo.y), ImVec2(150, 50), 40, ImVec4(0,0,0,0.8), Distance);
            }
        }
    }
    
    if(case3)
    {
        char localMyPos[128];
        sprintf(localMyPos, "x:%.1f y:%.1f z:%.1f", MyPos.X, MyPos.Y, MyPos.Z);
        string myPos(localMyPos);
        DrawBox(ImVec2(screenWidth *3/4, 20), ImVec2(350, 50), 40, ImVec4(0,0,0,0.8), myPos.c_str());
        DrawBox(ImVec2(screenWidth *3/4, 70), ImVec2(350, 50), 40, ImVec4(0,0,0,0.8), currentMap);
    }
    
}*/
