#ifndef MENU
#define MENU  
#include "draw.h"
namespace Menu
{
    using namespace ImGui;   
    using namespace ESP; 
    using namespace Il2Cpp;
    bool hienmenu = false, iconmenu = true;
    
    void DrawESP();
    
	void DrawMenu()
	{
        if (SetResolution && screenWidth != Width && Width != 0)
        {
            SetResolution(Width, Height, true);
        }
        
	    iconmenu = !hienmenu;
		
	    if (screenWidth == Width) {
            if (iconmenu)
            {
                ImGui::Begin("", 0, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoBackground);
                ImGui::SetNextWindowSize(ImVec2(screenWidth * 0.30f, screenHeight * 0.70f), ImGuiCond_Once);
                if(ImGui::Button(ICON_FA_CUBE" Open Menu"))
                {
                    hienmenu = true; 
                    iconmenu = false;
                }
                ImGui::End();
            }
            if (hienmenu) 
            {
                ImGuiWindowFlags window_flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav;
                ImGui::Begin(ICON_FA_CUBES" Shyke Mod",&hienmenu,ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoCollapse);
                if (ImGui::BeginTabBar("TabShyke", ImGuiTabBarFlags_None))
                {                       
                    if (ImGui::BeginTabItem("Misc"))
                    {
						ImGui::Checkbox("Unlock Skins", &skin);
                        ImGui::EndTabItem();
                    }
                    
                    ImGui::EndTabBar();
                } 
                ImGui::End();
            }
        }
	}

	void DrawImGui()
	{
		if (init && screenHeight>0)
		{
		
			ImGuiIO &io = GetIO();
			static bool WantTextInputLast = false;
			ImGui_ImplOpenGL3_NewFrame();
			ImGui_ImplAndroid_NewFrame(screenWidth, screenHeight);
			NewFrame();
			DrawMenu();
			Render();
			ImGui_ImplOpenGL3_RenderDrawData(GetDrawData());
			EndFrame();
		}
	}
}
#endif MENU

