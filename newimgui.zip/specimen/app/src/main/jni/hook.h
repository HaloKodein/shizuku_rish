
void (*SetResolution)(int width, int height, bool fullscreen);
void (*set_timeScale)(float value);

int sliderValue = 1, level = 0;
void *instanceBtn;
uintptr_t il2cpp, unity, anogs;
typedef unsigned long long QWORD;
Vector3 MyPos;
ImVec2 DrawFrom(0,0), DrawTo(0,0); 
const char* currentMap; 

MemmoryController gg;

bool skin = false;
uintptr_t addr = 0x1AF4AC8;
bool (*oldCanUseSkin)(void *instance);
bool CanUseSkin(void *instance) {
	if (instance != NULL) {
		return skin;
	}
			
	return oldCanUseSkin(instance);
}

