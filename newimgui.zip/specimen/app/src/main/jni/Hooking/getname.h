monoString* (*_getName)(...);
monoString* getName(void *instance)
{
    char buf[128];
    sprintf(buf, "%s", _getName(instance)->get_const_char());
    currentMap = Strdup(buf); 
    return _getName(instance);
}

monoString *(*get_unityVersion)(...);
monoString *(*get_version)(...);
monoString *(*get_productName)(...);