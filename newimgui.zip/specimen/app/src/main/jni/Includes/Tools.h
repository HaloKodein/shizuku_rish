#include "Includes.h"
#include "Substrate/CydiaSubstrate.h"
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string>
#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sstream>
#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>
#include "Il2Cpp.h"
#include <KittyMemory/KittyMemory.h>
#include <KittyMemory/MemoryPatch.h>
#include <KittyMemory/KittyScanner.h>
#include <KittyMemory/KittyUtils.h>

// typedef unsigned __int64 QWORD;

namespace Tools
{
    void Hook(void *target, void *replace, void **backup);
    bool Read(void *addr, void *buffer, size_t length);
    bool Write(void *addr, void *buffer, size_t length);
    bool ReadAddr(void *addr, void *buffer, size_t length);
    bool WriteAddr(void *addr, void *buffer, size_t length);

    bool PVM_ReadAddr(void *addr, void *buffer, size_t length);
    bool PVM_WriteAddr(void *addr, void *buffer, size_t length);

    bool IsPtrValid(void *addr);

    uintptr_t GetBaseAddress(const char *name);
    uintptr_t GetEndAddress(const char *name);
    uintptr_t FindPattern(const char *lib, const char *pattern);
    uintptr_t FindPointer(uintptr_t Lib, uintptr_t base, std::vector<uintptr_t> offsets);
    std::string RandomString(const int len);
    std::string GetPackageName(JNIEnv *env, jobject context);
}

#define HOOK(adr, ptr, orig) Tools::Hook((void *)adr, (void *)ptr, (void **)&orig)

template <typename T>
T ReadAddress(unsigned long long addr)
{
    char result[1024];
    Tools::ReadAddr((void *)addr, result, sizeof(T));
    return *(T *)result;
}

template <typename T>
void WriteAddress(unsigned long long addr, T newValue)
{
    KittyMemory::memWrite((void *)addr, ((char *)&newValue), sizeof(T));
}

struct MemPage
{
    long start;
    long end;
    char flags[8];
    char name[128];
    void *buf = NULL;
};

struct MemmoryController
{
    std::vector<uintptr_t> addrs;
    int pointerAddrs;

    enum
    {
        REGION_Auto, // 0
        REGION_A,    // 1
        REGION_Ca,   // 2
        REGION_Cd,   // 3
        REGION_Cb,   // 4
        REGION_Jh,   // 5
        REGION_J,    // 6
        REGION_S,    // 7
        REGION_V,    // 8
        REGION_Xa,   // 9
        REGION_Xs,   // 10
        REGION_As,   // 11
        REGION_B,    // 12
        REGION_O,    // 13
    };

    int memContrast(char *str)
    {
        if (strstr(str, "/Metadata/global-metadata.dat") != NULL)
            return REGION_O;
        if (strlen(str) == 0)
            return REGION_A;
        if (strstr(str, "/dev/ashmem/") != NULL)
            return REGION_As;
        if (strstr(str, "/system/fonts/") != NULL)
            return REGION_B;
        if (strstr(str, "/data/app/") != NULL)
            return REGION_Xa;
        if (strstr(str, "/system/framework/") != NULL)
            return REGION_Xs;
        if (strcmp(str, "[anon:libc_malloc]") == 0)
            return REGION_Ca;
        if (strstr(str, ":bss") != NULL)
            return REGION_Cb;
        if (strstr(str, "/data/data/") != NULL)
            return REGION_Cd;
        if (strstr(str, "[anon:dalvik") != NULL)
            return REGION_J;
        if (strcmp(str, "[stack]") == 0)
            return REGION_S;
        if (strcmp(str, "/dev/kgsl-3d0") == 0)
            return REGION_V;
    }

    void search(const void *value, int mem, size_t size)
    {
        addrs.clear();
        MemPage *mp = NULL;
        char filename[32];
        char line[1024];
        FILE *fp = fopen("/proc/self/maps", "r");
        if (fp != NULL)
        {
            while (fgets(line, sizeof(line), fp))
            {
                mp = (MemPage *)calloc(1, sizeof(MemPage));
                sscanf(line, "%p-%p %s %*p %*p:%*p %*p   %[^\n]%s", &mp->start, &mp->end, mp->flags, mp->name);
                if ((memContrast(mp->name) == mem) && strstr(mp->flags, "r") != NULL)
                {
                    std::vector<uintptr_t> found_addr = KittyScanner::findDataAll(mp->start, mp->end, value, size);
                    for (int i = 0; i < found_addr.size(); i++)
                        addrs.push_back(found_addr[i]);
                }
            }
            fclose(fp);
        }
    }

    void searchPointer(const void *value)
    {
        addrs.clear();
        MemPage *mp = NULL;
        char filename[32];
        char line[1024];
        FILE *fp = fopen("/proc/self/maps", "r");
        if (fp != NULL)
        {
            while (fgets(line, sizeof(line), fp))
            {
                mp = (MemPage *)calloc(1, sizeof(MemPage));
                sscanf(line, "%p-%p %s %*p %*p:%*p %*p   %[^\n]%s", &mp->start, &mp->end, mp->flags, mp->name);
                if ((memContrast(mp->name) == 1) && strstr(mp->flags, "r") != NULL)
                {
                    std::vector<uintptr_t> found_addr = KittyScanner::findDataAll(mp->start, mp->end, value, 8);
                    for (int i = 0; i < found_addr.size(); i++)
                    {
                        if (*(int *)(found_addr[i] - 0x4) == 0)
                            addrs.push_back(found_addr[i]);
                    }
                }
            }
            fclose(fp);
        }
    }

    int GetClass(const char *Dll, const char *namespaze, const char *clazzName)
    {
        LOGI("Pointer Addr: %X", (int)Il2Cpp::GetClass(Dll, namespaze, clazzName));
        return (int)Il2Cpp::GetClass(Dll, namespaze, clazzName);
    }

    void clearReasult()
    {
        addrs.clear();
    }
};