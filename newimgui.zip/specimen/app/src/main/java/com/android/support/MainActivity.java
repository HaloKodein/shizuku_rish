package com.android.support;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.DisplayMetrics;
public class MainActivity extends Activity {

    //Only if you have changed MainActivity to yours and you wanna call game's activity.
    public String GameActivity = "com.google.firebase.MessagingUnityPlayerActivity";
    public boolean hasLaunched = false;
	
    //To call onCreate, please refer to README.md
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //To launch game activity
        if (!hasLaunched) { 
            hasLaunched = true;
                //Launch mod menu.
            System.loadLibrary("Shyke"); 
            return; 
        }
        System.loadLibrary("Shyke"); 
        
    }
}
